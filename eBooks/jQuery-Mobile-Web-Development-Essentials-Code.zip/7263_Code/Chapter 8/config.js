$(document).bind("mobileinit",  function() {
	$.mobile.defaultPageTransition = "fade";
	$.mobile.loadingMessage="Fetching page...";
});
