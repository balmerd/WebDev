var dummyContacts = [

  {
    "city": "Cupertino",
    "contacts": [

      {
        "displayName": "Tim Cook",
        "addresses": [
          {
            "streetAddress": "1 Infinite Loop",
            "locality": "Cupertino"
          }
        ]
      },
   
      {
        "displayName": "Ronald McDonald",
        "addresses": [
          {
            "streetAddress": "10990 North Stelling Road",
            "locality": "Cupertino"
          }
        ]
      },
 
      {
        "displayName": "Colonel Sanders",
        "addresses": [
          {
            "streetAddress": "10520 South De Anza Boulevard",
            "locality": "Cupertino"
          }
        ]
      },

      {
        "displayName": "Tommy Taco",
        "addresses": [
          {
            "streetAddress": "10710 South De Anza Boulevard",
            "locality": "Cupertino"
          }
        ]
      }

    ]
  },

  {
    "city": "Mountain View",
    "contacts": [

      {
        "displayName": "Larry Page",
        "addresses": [
          {
            "streetAddress": "1600 Amphitheatre Parkway",
            "locality": "Mountain View"
          }
        ]
      },
   
      {
        "displayName": "Steve Ballmer",
        "addresses": [
          {
            "streetAddress": "1065 La Avenida Street",
            "locality": "Mountain View"
          }
        ]
      },
 
      {
        "displayName": "Mary Starbuck",
        "addresses": [
          {
            "streetAddress": "1750 Miramonte Avenue",
            "locality": "Mountain View"
          }
        ]
      }

    ]
  },

  {
    "city": "Redwood City",
    "contacts": [

      {
        "displayName": "Larry Ellison",
        "addresses": [
          {
            "streetAddress": "500 Oracle Parkway",
            "locality": "Redwood City"
          }
        ]
      },
   
      {
        "displayName": "John Riccitiello",
        "addresses": [
          {
            "streetAddress": "209 Redwood Shores Parkway",
            "locality": "Redwood City"
          }
        ]
      }

    ]
  }

];

