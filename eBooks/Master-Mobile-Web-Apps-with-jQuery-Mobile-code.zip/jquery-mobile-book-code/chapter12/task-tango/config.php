<?php

ini_set( "log_errors", true );
ini_set( "error_reporting", E_ALL );
ini_set( "error_log", "/path/to/task-tango/folder/error_log" );

date_default_timezone_set( "Australia/Sydney" );  // http://www.php.net/manual/en/timezones.php
define( "APP_URL", "index.php" );
define( "DB_DSN", "mysql:host=localhost;dbname=tasktango" );
define( "DB_USERNAME", "root" );
define( "DB_PASSWORD", "password" );
define( "CLASS_PATH", "classes" );
define( "TEMPLATE_PATH", "templates" );
define( "PASSWORD_EMAIL_FROM_NAME", "Task Tango" );
define( "PASSWORD_EMAIL_FROM_ADDRESS", "your_email_address" );
define( "PASSWORD_EMAIL_SUBJECT", "Your New Task Tango Password" );
define( "PASSWORD_EMAIL_APP_URL", "http://your-site-url/task-tango/" );
require( CLASS_PATH . "/User.php" );
require( CLASS_PATH . "/Todo.php" );
?>
