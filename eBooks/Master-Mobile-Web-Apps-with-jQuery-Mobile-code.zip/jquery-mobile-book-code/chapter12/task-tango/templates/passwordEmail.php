Hi there,

Here's your new password:

<?php echo $this->plaintextPassword ?>


Visit the link below to use Task Tango:

<?php echo PASSWORD_EMAIL_APP_URL ?>
